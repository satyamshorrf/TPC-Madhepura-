<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>::Photo Gallery:: Thakur Prasad College, Madhepura</title>
<script src="../scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
<script src="../scripts/script.js" type="text/javascript"></script>
<link href="../lightbox/css/jquery.lightbox-0.5.css" rel="stylesheet" type="text/css"/>
<script src="../lightbox/js/jquery.lightbox-0.5.pack.js" type="text/javascript"></script>
<link href="../styles/demo.css" rel="stylesheet" type="text/css"/>
<link href="../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<script src="../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
</head>

<body>
    
        <!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="en">
<head>
<meta charset="UTF-8">
<title></title>

<link href="../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<script src="../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../scripts/jquery-1.9.1.min.js" type="text/javascript"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link href="styles/custom-menu.css" rel="stylesheet" type="text/css"/>
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon"/>
<style type="text/css">
  
.header_bg{
    background: #20242C;
}
.tpc_logo{
                background: #20242C;
                width: 100%;
                
                margin-bottom: 5px;
            }
</style>
<script>

$(document).ready(function() {
	function bindNavbar() {
		if ($(window).width() > 767) {
			$('.navbar-default .dropdown').on('mouseover', function(){
				$('.dropdown-toggle', this).next('.dropdown-menu').show();
			}).on('mouseout', function(){
				$('.dropdown-toggle', this).next('.dropdown-menu').hide();
			});
			
			$('.dropdown-toggle').click(function() {
				if ($(this).next('.dropdown-menu').is(':visible')) {
					window.location = $(this).attr('href');
				}
			});
		}
		else {
			$('.navbar-default .dropdown').off('mouseover').off('mouseout');
		}
	}
	
	$(window).resize(function() {
		bindNavbar();
	});
	
	bindNavbar();
});
</script>

</head> 
<body >
   
    <div class="header_bg">
            <div class="container">
                <div class="row header">
                    <div class=" col-md-10">
                    <div class="tpc_logo navbar-left">
                        <img class="img-responsive" src="images/tpcollege.png" alt="Thakur Prasad College ,Madhepura"/>
                    </div>
                    </div>
                    <div class=" col-sm-2 pull-right ">
                     <div class="">
                         <a href="https://tp.collegeesolution.in/">
                             <button class="btn-ext" onclick="alert('You are being redirected to Apply-online section.')"><img class=" img-responsive" src="images/onld.gif" alt=""  style=" margin-top: 5px;"/></a>
                    </div>
                    </div>
                </div>    
            </div>
        </div>
        
    <nav role="navigation" class="navbar navbar-default" id="custom-bootstrap-menu">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            
        </div>
        <!-- Collection of nav links and other content for toggling -->
        <div id="navbarCollapse" class="collapse navbar-collapse navbar-menubuilder">
            <ul class="nav navbar-nav">
                <li class=" text-uppercase"><a href="index.php?term=Home"><span class="glyphicon glyphicon-home"></span> Home&nbsp;</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown" > &nbsp;About Us &nbsp; <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="intro.php?term=Introduction">Introduction</a></li>
                        <li><a href="principles_msg.php?term=Principle's Message">Principal's Message</a></li>
                        <li><a href="goals&objective.php?term=Goals & Objective">Goals & Objective</a></li>
                        <li><a href="#">UGC 2f &amp; 12b</a></li>
                        <li><a href="faculty.php">Faculty</a></li>
                        <li><a href="rules.php">Rules &amp; Regulation</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">&nbsp; &nbsp;Academic&nbsp; &nbsp; <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="admission.php">Admission</a></li>
                        <li><a href="examinations.php">Examination</a></li>
                        <li><a href="departments.php">Department</a></li>
                        <li><a href="#">Previous Year Questions</a></li>
                        <li><a href="fee&scholarship.php">Fee &amp; Scholarship</a></li>
                        <li><a href="calendar.php">Academic Calendar</a></li>
                        <li><a href="holidays.php">List of Holidays</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">&nbsp; &nbsp;Courses&nbsp;  <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
						<li><a href="onlinecourses.php">Online Courses</a></li>
                        <li><a href="course_higher_sec.php">Higher Secondary Courses</a></li>
                        <li><a href="course_ug.php">Under Graduate Courses</a></li>
                        <li><a href="course_pg.php">Post Graduate Courses</a></li>
                        <li><a href="course_voc.php">Vocational Program Courses</a></li>
                    </ul>
                </li>
                <!--<li><a href="campus.php">Campus</a></li>-->
                
                <li class="dropdown">
                    <a class="dropdown-toggle text-uppercase" data-toggle="dropdown" href="#"> &nbsp;Result&nbsp;  <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="student_exam_result_ug.php">Under Graduate Course Result</a></li>
                        <li><a href="student_exam_result_pg.php">Post Graduate Course Result</a></li>
                        <li><a href="student_exam_result_voc.php">Vocational Course Result</a></li>
                        
                    </ul>
                </li>
                <li class="text-uppercase"><a href="gallery.php">Photo Gallery</a></li>
                <li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="dropdown" href="#">Downloads &nbsp;<strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="downloads.php">Download Prospectus</a></li>
                        <li><a href="#">Admission Form</a></li>
                        <li><a href="#">Other Forms</a></li>
                    </ul>
                </li>
				<li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="dropdown" href="#">NAAC &nbsp;<strong class="caret"></strong></a>
				<ul class="dropdown-menu">
                        <li><a href="naac.php">NAAC</a></li>
                        <li><a href="single.php">Contact Us</a></li>
                        
                    </ul>
                
				
                
            </ul>
            
        </div>
    </div>
        <!--<li class=" nav navbar-nav navbar-right dropdown">
                    <a class=" dropdown-toggle" data-toggle="dropdown" href="#"><i class=" glyphicon glyphicon-log-in"></i> Login </a>
                <ul class="dropdown-menu">
                    <li><a href="#">Admin Login</a></li>
                    <li><a href="#">Student Login</a></li>
                </ul>
                </li>-->
</nav>
    
</body>
</html>    
    <section class="container">
        <div class="row">
            <!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        
    </head>
    <body>
        
            
                <div class="col-sm-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4>Quick Links</h4>
                        </div>
                        <div class="panel-body">
                            <ul class="list-group">
                                <a href="index.php" class="list-group-item">Home</a>
                                <a href="intro.php" class="list-group-item">Introduction</a>
                                <a href=principles_msg.php#" class="list-group-item">Principle's Desk</a>
                                <a href="onlinecourses.php" class="list-group-item">Online Courses</a>
                                <a href="faculty.php" class="list-group-item">Directory</a>
								<a href="naac.php" class="list-group-item">NAAC</a>
                                <a href="rules.php" class="list-group-item">Rules &amp; Regulation</a>
                                <a href="admission.php" class="list-group-item">Admission Notice</a>
                                <a href="fee&scholarship.php" class="list-group-item">Fee &amp; Scholarship</a>
                                
                                <a href="#" class="list-group-item">Academic Calender</a>
                                <a href="holidays.php" class="list-group-item">List of Holidays</a>
                                <a href="http://tpcollegebed.org/" class="list-group-item">B.Ed.</a>
                            </ul>
                        </div>
                    </div>
                </div>
            
    </body>
</html>
            <div class="col-sm-9" style="width: 75% ;">
                
                <div  id="page-heading" class="col-xs-9">
                    <h2 class="text-center">T.P. College Photo Gallery</h2>
                </div>
                <div class="image_gallery">
                <div id="container">
                        <div id="gallery">
                            
There is an error with your image directory!