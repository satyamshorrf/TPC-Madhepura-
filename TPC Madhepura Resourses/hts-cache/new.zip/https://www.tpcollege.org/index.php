<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
	
        <meta charset="UTF-8">
        <title>::Welcome to the Official website of T. P. College,Madhepura | www.tpcollege.org::</title>
        <meta name="description" content="Thakur Prasad College (T.P. College ) was established on 28 July 1953 after a series of meetings and consultations with different stakeholders in the region.The college is named after Babu Thakur Prasad Mandal who was father of Babu Kirti Narayan Mandal.Babu Thakur Prasad not only donated his land and money for the college but also along with Kirti Babu put great efforts in bringing the college in the present shape. " />
        <meta name="keywords" content="T P College Madhepura,tp college,tp college madhepura,official website of tp college,thakur prasad college,Colleges in Madhepura,Madhepura District College,B N M U Madhepura" />
<link rel="canonical" href="https://www.tpcollege.org/T.P.College Madhepura/"/>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name=viewport content="width=device-width, initial-scale=1">
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@T.P. College twitter account">
<meta name="twitter:title" content="Thakur Prasad College,www.tpcollege.org">
<meta name="twitter:description" content="Thakur Prasad College (T.P. College ) was established on 28 July 1953 after a series of meetings and consultations with different stakeholders in the region.The college is named after Babu Thakur Prasad Mandal who was father of Babu Kirti Narayan Mandal.Babu Thakur Prasad not only donated his land and money for the college but also along with Kirti Babu put great efforts in bringing the college in the present shape.">
<meta name="twitter:creator" content="@tpcollege">
<meta property="og:title" content="Thakur Prasad College | tpcollege.org" />
<meta property="og:type" content="website" />
<meta property="og:url" content="https://www.tpcollege.org/" />
<meta property="og:description" content="Thakur Prasad College (T.P. College ) was established on 28 July 1953 after a series of meetings and consultations with different stakeholders in the region.The college is named after Babu Thakur Prasad Mandal who was father of Babu Kirti Narayan Mandal.Babu Thakur Prasad not only donated his land and money for the college but also along with Kirti Babu put great efforts in bringing the college in the present shape." />
<meta property="og:site_name" content="tpcollege.org" />
<meta property="fb:admins" content="" />
<meta property='fb:app_id' content=''>
<link href="https://plus.google.com/u/0/113662637588152401489" rel="publisher">
        <script src="../scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="../scripts/docs.min.js" type="text/javascript"></script>
        <script src="../scripts/ie10-viewport-bug-workaround.js" type="text/javascript"></script>
        <link href="../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
        <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="../scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="../scripts/jssor.slider.mini.js" type="text/javascript"></script>
        <link href="styles/news-style.css" rel="stylesheet" type="text/css"/>
        <style>
            .feature{margin-top: 10px;}
            .text-bold{font-weight: bold; }
            .logo-border{height: 110px; width: 110px;border: 2px solid #31B0D5; border-radius: 50%; float: left; margin: 15px;}
            .logo-small{font-size: 36px; color: #31B0D5;margin: 30% 30% 30% 30% ; }
            .logo-header{font: 18px sans-serif; font-weight: bold;}
         carousel-inner > .item > img,
         .carousel-inner > .item > a > img {
            height:  110%;
            margin: auto;
         }
  
  ul a{text-decoration: none;}
  #jumbotron_bg{
      background: transparent url('images/home-bg.jpg')repeat-y center fixed ;
      -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
  -webkit-box-shadow: inset 0 -4px 9px -3px #000;
  -moz-box-shadow: inset 0 -4px 9px -3px #000;
  box-shadow: inset 0 -4px 9px -3px #000;
  
  }
  .jumbotron {
      
     
}
        </style>
        <script>/*--
$(document).ready(function(){
    // Activate Carousel
    $("#myCarousel").carousel();
    
    // Enable Carousel Indicators
    $(".item1").click(function(){
        $("#myCarousel").carousel(0);
    });
    $(".item2").click(function(){
        $("#myCarousel").carousel(1);
    });
    $(".item3").click(function(){
        $("#myCarousel").carousel(2);
    });
    $(".item4").click(function(){
        $("#myCarousel").carousel(3);
    });
    $(".item5").click(function(){
        $("#myCarousel").carousel(4);
    });
    $(".item6").click(function(){
        $("#myCarousel").carousel(5);
    });
    
    // Enable Carousel Controls
    $(".left").click(function(){
        $("#myCarousel").carousel("prev");
    });
    $(".right").click(function(){
        $("#myCarousel").carousel("next");
    });
});*/
</script>
<script src="../scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
<link href="../styles/styles.css" rel="stylesheet" type="text/css"/>
<script>

        jQuery(document).ready(function ($) {
            var options = {
                $AutoPlay: true,                                    //[Optional] Whether to auto play, to enable slideshow, this option must be set to true, default value is false
                $AutoPlaySteps: 1,                                  //[Optional] Steps to go for each navigation request (this options applys only when slideshow disabled), the default value is 1
                $AutoPlayInterval: 2000,                            //[Optional] Interval (in milliseconds) to go for next slide since the previous stopped if the slider is auto playing, default value is 3000
                $PauseOnHover: 1,                                   //[Optional] Whether to pause when mouse over if a slider is auto playing, 0 no pause, 1 pause for desktop, 2 pause for touch device, 3 pause for desktop and touch device, 4 freeze for desktop, 8 freeze for touch device, 12 freeze for desktop and touch device, default value is 1

                $ArrowKeyNavigation: true,   			            //[Optional] Allows keyboard (arrow key) navigation or not, default value is false
                $SlideEasing: $JssorEasing$.$EaseOutQuint,          //[Optional] Specifies easing for right to left animation, default value is $JssorEasing$.$EaseOutQuad
                $SlideDuration: 800,                                //[Optional] Specifies default duration (swipe) for slide in milliseconds, default value is 500
                $MinDragOffsetToSlide: 20,                          //[Optional] Minimum drag offset to trigger slide , default value is 20
                //$SlideWidth: 600,                                 //[Optional] Width of every slide in pixels, default value is width of 'slides' container
                //$SlideHeight: 300,                                //[Optional] Height of every slide in pixels, default value is height of 'slides' container
                $SlideSpacing: 0, 					                //[Optional] Space between each slide in pixels, default value is 0
                $DisplayPieces: 1,                                  //[Optional] Number of pieces to display (the slideshow would be disabled if the value is set to greater than 1), the default value is 1
                $ParkingPosition: 0,                                //[Optional] The offset position to park slide (this options applys only when slideshow disabled), default value is 0.
                $UISearchMode: 1,                                   //[Optional] The way (0 parellel, 1 recursive, default value is 1) to search UI components (slides container, loading screen, navigator container, arrow navigator container, thumbnail navigator container etc).
                $PlayOrientation: 1,                                //[Optional] Orientation to play slide (for auto play, navigation), 1 horizental, 2 vertical, 5 horizental reverse, 6 vertical reverse, default value is 1
                $DragOrientation: 1,                                //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $DisplayPieces is greater than 1, or parking position is not 0)

                $ArrowNavigatorOptions: {                           //[Optional] Options to specify and enable arrow navigator or not
                    $Class: $JssorArrowNavigator$,                  //[Requried] Class to create arrow navigator instance
                    $ChanceToShow: 2,                               //[Required] 0 Never, 1 Mouse Over, 2 Always
                    $AutoCenter: 2,                                 //[Optional] Auto center arrows in parent container, 0 No, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
                    $Steps: 1,                                      //[Optional] Steps to go for each navigation request, default value is 1
                    $Scale: false,                                  //Scales bullets navigator or not while slider scale
                },

                $BulletNavigatorOptions: {                                //[Optional] Options to specify and enable navigator or not
                    $Class: $JssorBulletNavigator$,                       //[Required] Class to create navigator instance
                    $ChanceToShow: 2,                               //[Required] 0 Never, 1 Mouse Over, 2 Always
                    $AutoCenter: 1,                                 //[Optional] Auto center navigator in parent container, 0 None, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
                    $Steps: 1,                                      //[Optional] Steps to go for each navigation request, default value is 1
                    $Lanes: 1,                                      //[Optional] Specify lanes to arrange items, default value is 1
                    $SpacingX: 12,                                   //[Optional] Horizontal space between each item in pixel, default value is 0
                    $SpacingY: 4,                                   //[Optional] Vertical space between each item in pixel, default value is 0
                    $Orientation: 1,                                //[Optional] The orientation of the navigator, 1 horizontal, 2 vertical, default value is 1
                    $Scale: false,                                  //Scales bullets navigator or not while slider scale
                }
            };

            //Make the element 'slider1_container' visible before initialize jssor slider.
            $("#slider1_container").css("display", "block");
            var jssor_slider1 = new $JssorSlider$("slider1_container", options);

            //responsive code begin
            //you can remove responsive code if you don't want the slider scales while window resizes
            function ScaleSlider() {
                var parentWidth = jssor_slider1.$Elmt.parentNode.clientWidth;
                if (parentWidth) {
                    jssor_slider1.$ScaleWidth(parentWidth - 30);
                }
                else
                    window.setTimeout(ScaleSlider, 30);
            }
            ScaleSlider();

            $(window).bind("load", ScaleSlider);
            $(window).bind("resize", ScaleSlider);
            $(window).bind("orientationchange", ScaleSlider);
            //responsive code end
        });
    </script>
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-7552907288172692",
    enable_page_level_ads: true
  });
</script>
    </head>
    <body>
       <!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="en">
<head>
<meta charset="UTF-8">
<title></title>

<link href="../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<script src="../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../scripts/jquery-1.9.1.min.js" type="text/javascript"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link href="styles/custom-menu.css" rel="stylesheet" type="text/css"/>
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon"/>
<style type="text/css">
  
.header_bg{
    background: #20242C;
}
.tpc_logo{
                background: #20242C;
                width: 100%;
                
                margin-bottom: 5px;
            }
</style>
<script>

$(document).ready(function() {
	function bindNavbar() {
		if ($(window).width() > 767) {
			$('.navbar-default .dropdown').on('mouseover', function(){
				$('.dropdown-toggle', this).next('.dropdown-menu').show();
			}).on('mouseout', function(){
				$('.dropdown-toggle', this).next('.dropdown-menu').hide();
			});
			
			$('.dropdown-toggle').click(function() {
				if ($(this).next('.dropdown-menu').is(':visible')) {
					window.location = $(this).attr('href');
				}
			});
		}
		else {
			$('.navbar-default .dropdown').off('mouseover').off('mouseout');
		}
	}
	
	$(window).resize(function() {
		bindNavbar();
	});
	
	bindNavbar();
});
</script>

</head> 
<body >
   
    <div class="header_bg">
            <div class="container">
                <div class="row header">
                    <div class=" col-md-10">
                    <div class="tpc_logo navbar-left">
                        <img class="img-responsive" src="images/tpcollege.png" alt="Thakur Prasad College ,Madhepura"/>
                    </div>
                    </div>
                    <div class=" col-sm-2 pull-right ">
                     <div class="">
                         <a href="https://tp.collegeesolution.in/">
                             <button class="btn-ext" onclick="alert('You are being redirected to Apply-online section.')"><img class=" img-responsive" src="images/onld.gif" alt=""  style=" margin-top: 5px;"/></a>
                    </div>
                    </div>
                </div>    
            </div>
        </div>
        
    <nav role="navigation" class="navbar navbar-default" id="custom-bootstrap-menu">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            
        </div>
        <!-- Collection of nav links and other content for toggling -->
        <div id="navbarCollapse" class="collapse navbar-collapse navbar-menubuilder">
            <ul class="nav navbar-nav">
                <li class=" text-uppercase"><a href="index.php?term=Home"><span class="glyphicon glyphicon-home"></span> Home&nbsp;</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown" > &nbsp;About Us &nbsp; <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="intro.php?term=Introduction">Introduction</a></li>
                        <li><a href="principles_msg.php?term=Principle's Message">Principal's Message</a></li>
                        <li><a href="goals&objective.php?term=Goals & Objective">Goals & Objective</a></li>
                        <li><a href="#">UGC 2f &amp; 12b</a></li>
                        <li><a href="faculty.php">Faculty</a></li>
                        <li><a href="rules.php">Rules &amp; Regulation</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">&nbsp; &nbsp;Academic&nbsp; &nbsp; <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="admission.php">Admission</a></li>
                        <li><a href="examinations.php">Examination</a></li>
                        <li><a href="departments.php">Department</a></li>
                        <li><a href="#">Previous Year Questions</a></li>
                        <li><a href="fee&scholarship.php">Fee &amp; Scholarship</a></li>
                        <li><a href="calendar.php">Academic Calendar</a></li>
                        <li><a href="holidays.php">List of Holidays</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">&nbsp; &nbsp;Courses&nbsp;  <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
						<li><a href="onlinecourses.php">Online Courses</a></li>
                        <li><a href="course_higher_sec.php">Higher Secondary Courses</a></li>
                        <li><a href="course_ug.php">Under Graduate Courses</a></li>
                        <li><a href="course_pg.php">Post Graduate Courses</a></li>
                        <li><a href="course_voc.php">Vocational Program Courses</a></li>
                    </ul>
                </li>
                <!--<li><a href="campus.php">Campus</a></li>-->
                
                <li class="dropdown">
                    <a class="dropdown-toggle text-uppercase" data-toggle="dropdown" href="#"> &nbsp;Result&nbsp;  <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="student_exam_result_ug.php">Under Graduate Course Result</a></li>
                        <li><a href="student_exam_result_pg.php">Post Graduate Course Result</a></li>
                        <li><a href="student_exam_result_voc.php">Vocational Course Result</a></li>
                        
                    </ul>
                </li>
                <li class="text-uppercase"><a href="gallery.php">Photo Gallery</a></li>
                <li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="dropdown" href="#">Downloads &nbsp;<strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="downloads.php">Download Prospectus</a></li>
                        <li><a href="#">Admission Form</a></li>
                        <li><a href="#">Other Forms</a></li>
                    </ul>
                </li>
				<li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="dropdown" href="#">NAAC &nbsp;<strong class="caret"></strong></a>
				<ul class="dropdown-menu">
                        <li><a href="naac.php">NAAC</a></li>
                        <li><a href="single.php">Contact Us</a></li>
                        
                    </ul>
                
				
                
            </ul>
            
        </div>
    </div>
        <!--<li class=" nav navbar-nav navbar-right dropdown">
                    <a class=" dropdown-toggle" data-toggle="dropdown" href="#"><i class=" glyphicon glyphicon-log-in"></i> Login </a>
                <ul class="dropdown-menu">
                    <li><a href="#">Admin Login</a></li>
                    <li><a href="#">Student Login</a></li>
                </ul>
                </li>-->
</nav>
    
</body>
</html>        
        <div class="container">
        <!-- Jssor Slider Begin -->
        <!-- You can move inline styles to css file or css block. -->
        <!-- ================================================== -->
        <div class="row">
        <div class="col-sm-8">
        <div id="slider1_container" style="display: none; position: relative; margin: 0 auto; width: 980px;
        height: 480px; overflow: hidden;">

            <!-- Loading Screen -->
            <div u="loading" style="position: absolute; top: 0px; left: 0px;">
                <div style="filter: alpha(opacity=70); opacity:0.7; position: absolute; display: block;

                background-color: #000; top: 0px; left: 0px;width: 100%; height:100%;">
                </div>
                <div style="position: absolute; display: block; background: url(images/loading.gif) no-repeat center center;

                top: 0px; left: 0px;width: 100%;height:100%;">
                </div>
            </div>

            <!-- Slides Container -->
            <div u="slides" style="cursor: move; position: absolute; left: 0px; top: 0px; width: 1140px; height: 442px;
            overflow: hidden;">
                <div>
                    <img u="image" src2="../images/slider1.jpg" />
                </div>
                <div>
                    <img u="image" src2="../images/slider2.jpg" />
                </div>
                <div>
                    <img u="image" src2="../images/slider3.jpg" />
                </div>
                <div>
                    <img u="image" src2="../images/slider4.jpg" />
                </div>
            </div>
            <!-- Bullet Navigator Skin Begin -->
            
            <style>
                /* jssor slider bullet navigator skin 05 css */
                /*
                .jssorb05 div           (normal)
                .jssorb05 div:hover     (normal mouseover)
                .jssorb05 .av           (active)
                .jssorb05 .av:hover     (active mouseover)
                .jssorb05 .dn           (mousedown)
                */
                .jssorb05 div, .jssorb05 div:hover, .jssorb05 .av {
                    background: url(../images/b05.png) no-repeat;
                    overflow: hidden;
                    cursor: pointer;
                }

                .jssorb05 div {
                    background-position: -7px -7px;
                }

                    .jssorb05 div:hover, .jssorb05 .av:hover {
                        background-position: -37px -7px;
                    }

                .jssorb05 .av {
                    background-position: -67px -7px;
                }

                .jssorb05 .dn, .jssorb05 .dn:hover {
                    background-position: -97px -7px;
                }
            </style>
            <!-- bullet navigator container -->
            <div u="navigator" class="jssorb05" style="position: absolute; bottom: 36px; right: 6px;">
                <!-- bullet navigator item prototype -->
                <div u="prototype" style="position:  absolute; width: 16px; height: 16px;"></div>
            </div>
        </div>
            <!-- Bullet Navigator Skin End -->
            <!-- Arrow Navigator Skin Begin -->
            <style>
                /* jssor slider arrow navigator skin 11 css */
                /*
                .jssora11l              (normal)
                .jssora11r              (normal)
                .jssora11l:hover        (normal mouseover)
                .jssora11r:hover        (normal mouseover)
                .jssora11ldn            (mousedown)
                .jssora11rdn            (mousedown)
                */
                .jssora11l, .jssora11r, .jssora11ldn, .jssora11rdn {
                    position: absolute;
                    cursor: pointer;
                    display: block;
                    background: url(../images/a11.png) no-repeat;
                    overflow: hidden;
                }

                .jssora11l {
                    background-position: -11px -41px;
                }

                .jssora11r {
                    background-position: -71px -41px;
                }

                .jssora11l:hover {
                    background-position: -131px -41px;
                }

                .jssora11r:hover {
                    background-position: -191px -41px;
                }

                .jssora11ldn {
                    background-position: -251px -41px;
                }

                .jssora11rdn {
                    background-position: -311px -41px;
                }
            </style>
            <!-- Arrow Left -->
            <span u="arrowleft" class="jssora11l" style="width: 37px; height: 37px; top: 136px; left: 14px;">
            </span>
            <!-- Arrow Right -->
            <span u="arrowright" class="jssora11r" style="width: 37px; height: 37px; top: 130px; right: 14px">
            </span>
            <!-- Arrow Navigator Skin End -->
            
        </div>
        <!-- Jssor Slider End -->
    

        
            <div class="col-sm-4 ">
                <div class="panel panel-primary" id="event_cont">
                    <div class="panel-heading text-center"><strong class=""style="color: #FDE710; font-size: 16px;"><span class=" glyphicon glyphicon-list"></span> Notice Board</strong></div>
                    <div class="panel-body" >
                        <marquee direction="up" scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();" style="height: 215px;" scrolldelay=".0001"/>
                        <ul class="event_container" id="noticeboard">
                                                        <li class="event_item">
                                <p class="event_news"><i style="color: #FF0000;" class=" glyphicon glyphicon-arrow-right"></i> <a href="http://login.tpcollege.org/uploads/ad3.pdf"> &nbsp;<span class=" pull-right"><img class=" img-responsive" src="images/new.gif" alt="New"/></span>&nbsp; Canteen From</a> </p>
                                
                            </li>
                        
                                                    <li class="event_item">
                                <p class="event_news"><i style="color: #FF0000;" class=" glyphicon glyphicon-arrow-right"></i> <a href="http://login.tpcollege.org/uploads/ad.pdf"> &nbsp;<span class=" pull-right"><img class=" img-responsive" src="images/new.gif" alt="New"/></span>&nbsp; Canteen Related Information</a> </p>
                                
                            </li>
                        
                                                </ul>
                        </marquee>
                    </div>
                    <div class="panel-footer">
                        <p>//<a href="allnotice.php" target="_blank"> View All Notices </a>//</p>
                    </div>
                </div>
            </div>
        </div>
        </div>
    
        <hr/>
        
        <div class="jumbotron" id="jumbotron_bg">
            <div >
    <div class="container">
        <h2 class=" text-center">Welcome To T.P.College ,Madhepura</h2>
        <p>
            Bihar has been a renowned seat of learning since time immemorial. 
            This has been the land of enlightenment for the founders of some of the world's major 
            religions such as Buddhism, Jainism and Sikhism. At the same time, the state has the 
            history of giving..
            <div class="btn btn in center-block">
                <a href="intro.php" class="btn btn-lg btn-info">Know more..</a>
            </div>
</p>
    </div>
</div>
            
        </div>
<div class="container">
    <div class="row">
        <div class=" col-md-8">
            <div class=" page-header">
                <h3 class=" text-bold">Principal's Desk</h3>
        </div>
        <div class="col-sm-6">
            
            <div class="img-thumbnail">       
                <img class="img-responsive" src="../images/principle-image.jpg" alt="" width="360" height="360"/>
            </div>
            <div class="caption">
                <h4>PROF (DR.) KAILESH PRASAD YADAV</h4>
                <p>Principal,T.P.College,Madhepura</p>
            </div>
        </div>
            <p class="text-left" style="font-weight: bold; font-size: 18px;">Dear Students and Guardians,</p>
            <p class=" text-justify">When the new Prospectus is in your hands, I cannot resist myself from sharing my feelings with you, 
                particularly guardians, erudite  teachers, Non-teaching employees and students about the golden past, vibrant present and promising future of Thakur Prasad College, Madhepura.
                This backward region of Bihar still presents the latent longings and poor legacy of the past in spite of giving birth to Bhupendra Narayan Mandal, B.P. Mandal, Shivnandan Mandal,
                Kirti Narayan Mandal and so many immortal sons of the soil.
            <p>In the present era of universalization and liberalization, time is highly changing and challenging to new aspirants  of fast moving world. Now, job-oriented phase of time education 
                and knowledge construe to focus on committed facilities and opportunities providing employment and pivotal role in every walk of life....</p>    
            <div class="btn-group pull-right">
                <a href="principles_msg.php"><button type="" class="btn btn-info">Know more..</button></a>
            </div>
            </p>
            
        </div>   
        
    
        <div class="col-md-4" style=" margin-top: 75px;">
            <div class="panel panel-primary" id="event_cont">
            <div class="panel-heading">
                <h3 class="panel-title text-uppercase"><span class=" glyphicon glyphicon-list"></span>  &nbsp;&nbsp;&nbsp;<b>Campus Events</b></h3>
            </div>
            <div class="" onload="window.onload();">
                <marquee direction="up" scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();" style="height: 320px;"/>
                <ul class="event_container">
                
                                        <li class="event_item" >
                                <p class="event_news"> <span style="color: #FF0000;" class=" glyphicon glyphicon-arrow-right"></span> <a href="#">P.G. Admission Apply 19.12.2016 to 08-01-2017 </a></p>
                            </li>
                                                        <li class="event_item" >
                                <p class="event_news"> <span style="color: #FF0000;" class=" glyphicon glyphicon-arrow-right"></span> <a href="#"><a href="TPC 3 list.pdf">3rd Merit List for B.Ed. Admission â€“ 2016-2017 </a></a></p>
                            </li>
                                                        <li class="event_item" >
                                <p class="event_news"> <span style="color: #FF0000;" class=" glyphicon glyphicon-arrow-right"></span> <a href="#"><a href="TPC-2nd-list.pdf">Second Merit List for B.Ed. Admission â€“ 2016-2017 </a></a></p>
                            </li>
                                                        <li class="event_item" >
                                <p class="event_news"> <span style="color: #FF0000;" class=" glyphicon glyphicon-arrow-right"></span> <a href="#"><a href="Tpc B.Ed List.pdf"> Approved Admission List of B.Ed. 2016 - 18 </a>
</a></p>
                            </li>
                                                        <li class="event_item" >
                                <p class="event_news"> <span style="color: #FF0000;" class=" glyphicon glyphicon-arrow-right"></span> <a href="#">B.A. & B.Sc. Part 1 Admission Date</a></p>
                            </li>
                                                            </ul>
                </marquee>
                
           </div>
        </div>
        </div>
        </hr>
        
           </div>
           <div class="feature">
               <div class="row" >
        <div class="col-md-6">
            <div class="panel panel-default ">
                <div class="logo-border">
                <i class="glyphicon glyphicon-education logo-small" ></i>
                </div>
                <h3 class=" text-bold">Courses &amp; Programs</h3>
                <p class=" ">T. P. College offers full-time courses and full-time programs leading to certificates, diplomas, and applied degrees under B.N.M.U. Madhepura &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><button class="btn btn-info btn-sm">Read More..</button></a></p>
                
                
            </div>
        </div>
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="logo-border">
                <i class="glyphicon glyphicon-book logo-small" ></i>
                </div>
                <h3 class=" text-bold">Credit &amp; Grading System</h3>
                <p class=" ">UGC,NAAC is the need to develop a Choice-Based Credit System (CBCS) in tune with global trends and the adoption of a proper grading system for measuring performance of the learner.<a href="#"><button class="btn btn-info btn-sm">Read More..</button></a></p>
                
            </div>
        </div>
        <div class="col-md-6">
            <div class="panel panel-info">
                    <div class=" logo-border">
                <a href="#"><i class="glyphicon glyphicon-search logo-small" ></i></a>
                    </div>
                <h3 class="text-bold">Online Result</h3>
                <p>Online results in addition to displaying all current subject, the online interface allows detailed access to each subject. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><button class="btn btn-info btn-sm">Click Here..</button></a></p>
                </div>
        </div>
        <div class="col-md-6">
            <div class="panel panel-info">
                    <div class=" logo-border">
                <a href="#"><i class="glyphicon glyphicon-link logo-small" ></i></a>
                    </div>
                <h3 class=" text-bold">Online Admission </h3>
                <p>Welcome To Online Admission Registration 2016-17 for various courses in T.P. College,Madhepura run under B.N.M.U.,Madhepura Bihar.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><button class="btn btn-info btn-sm">Click Here..</button></a></p>
                </div>
        </div>
    </div>
</div>
    <script src="../scripts/jquery.cycle.all.js" type="text/javascript"></script>
    <script>
        jQuery(document).ready(function ($) {
            var options = {
                $AutoPlay: true,                                    //[Optional] Whether to auto play, to enable slideshow, this option must be set to true, default value is false
                $AutoPlaySteps: 1,                                  //[Optional] Steps to go for each navigation request (this options applys only when slideshow disabled), the default value is 1
                $AutoPlayInterval: 0,                            //[Optional] Interval (in milliseconds) to go for next slide since the previous stopped if the slider is auto playing, default value is 3000
                $PauseOnHover: 4,                               //[Optional] Whether to pause when mouse over if a slider is auto playing, 0 no pause, 1 pause for desktop, 2 pause for touch device, 3 pause for desktop and touch device, 4 freeze for desktop, 8 freeze for touch device, 12 freeze for desktop and touch device, default value is 1

                $ArrowKeyNavigation: true,   			            //[Optional] Allows keyboard (arrow key) navigation or not, default value is false
                $SlideEasing: $JssorEasing$.$EaseLinear,          //[Optional] Specifies easing for right to left animation, default value is $JssorEasing$.$EaseOutQuad
                $SlideDuration: 1600,                                //[Optional] Specifies default duration (swipe) for slide in milliseconds, default value is 500
                $MinDragOffsetToSlide: 20,                          //[Optional] Minimum drag offset to trigger slide , default value is 20
                $SlideWidth: 140,                                   //[Optional] Width of every slide in pixels, default value is width of 'slides' container
                //$SlideHeight: 100,                                //[Optional] Height of every slide in pixels, default value is height of 'slides' container
                $SlideSpacing: 0, 					                //[Optional] Space between each slide in pixels, default value is 0
                $DisplayPieces: 7,                                  //[Optional] Number of pieces to display (the slideshow would be disabled if the value is set to greater than 1), the default value is 1
                $ParkingPosition: 0,                              //[Optional] The offset position to park slide (this options applys only when slideshow disabled), default value is 0.
                $UISearchMode: 1,                                   //[Optional] The way (0 parellel, 1 recursive, default value is 1) to search UI components (slides container, loading screen, navigator container, arrow navigator container, thumbnail navigator container etc).
                $PlayOrientation: 1,                                //[Optional] Orientation to play slide (for auto play, navigation), 1 horizental, 2 vertical, 5 horizental reverse, 6 vertical reverse, default value is 1
                $DragOrientation: 1                                //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $DisplayPieces is greater than 1, or parking position is not 0)
            };

            var jssor_slider1 = new $JssorSlider$("slider2_container", options);

            //responsive code begin
            //you can remove responsive code if you don't want the slider scales while window resizes
            function ScaleSlider() {
                var bodyWidth = document.body.clientWidth;
                if (bodyWidth)
                    jssor_slider1.$ScaleWidth(Math.min(bodyWidth, 980));
                else
                    window.setTimeout(ScaleSlider, 30);
            }
            ScaleSlider();

            $(window).bind("load", ScaleSlider);
            $(window).bind("resize", ScaleSlider);
            $(window).bind("orientationchange", ScaleSlider);
            //responsive code end
        });
    </script>
        
<div class="feature">
    <div class="row" >
        <div class="col-sm-8">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        
                        <div class=" col-sm-3 ">
                            <div class="panel panel-default">
                                <div class="panel-thumbnail">
                                    <a href="http://www.ugc.ac.in" title=""><img class=" img-responsive" src="images/ugc_logo.jpg" alt=""  style=" margin: 5px auto;"/></a>
                                </div>
                                <div class="panel-body">
                                    <p>A Constituent of B.N.Mandal University,
                                        Madhepura(Bihar),</br>India Established since 1953,Recognised by UGC under 2F/2B since 1954.</p>
                                </div>
                            </div>
                        </div>
						
                        <div class="col-sm-5">
                            <div class="panel panel-default">
                                <div class="panel-thumbnail">
                                    <a href="http://www.ignou.ac.in/" title=""><img class=" img-rounded" src="images/ignou.jpg" alt="" /></a>
                                </div>
                                <div class="panel-body">
                                    <p>The basic goal of the institution is to impart qualitative and innovative</p>
                                </div>
                            </div>
                        </div>
						
                        <div class="col-sm-4">
                            <div class="panel panel-default">
                                <div class="panel-thumbnail">
                                    <center><a href="http://www.naac.gov.in" title=""><img class=" img-responsive" src="images/naac.jpg" alt="" /></a></center>
                                </div>
                                <div class="panel-body ">
                                    <p>Thakur Prasad College, Madhepura, a constitute unit of Bhupendra Narayan Mandal University, Madhepura,  NAAC in Processes  .</p>
                                </div>
                            </div>
                        </div>
					                       
                    </div>
                </div>
                </div>
            </div>
    

        <div class="col-sm-4 ">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h4>Important Links</h4> 
                </div>
                <div class="panel-body">
                    <div class="">
                    <ul class="list-group">
                        <a href="http://bnmu.ac.in/" class="list-group-item" target="_blank"><li>B.N. Mandal University,Madhepura</li></a>
                        <a href="http://www.biharboard.ac.in" class="list-group-item"target="_blank"><li><li>Bihar Board Patna</li></a>
                        <a href="https://www.ugc.ac.in" class="list-group-item" target="_blank"><li>UGC Website</li></a>
                        <a href="http://madhepura.bih.nic.in" class="list-group-item"target="_blank"><li><li>Madhepura Collectriate</li></a>
                        <a href="http://www.bihargov.bih.nic.in" class="list-group-item"target="_blank"><li><li>Bihar Govt. Official Website</li></a>
                        
                    </ul>
                    </div>
                </div>
            </div>
                        <a href="gallery.php"><img class="img-responsive" src="images/photogallery-h.gif" alt="" width="410"/> </a>
            
        </div>
        </div>
    </div>
</div>
    </section>
       
    <div class=" clearfix"></div>
      <!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet">
<link href="styles/styles.css" rel="stylesheet" type="text/css"/>

        <style>
            
        footer h3{color: #FFFFFF;}            
            .footer-distributed{
	background-color: #292c2f;
	box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
	box-sizing: border-box;
	width: 100%;
	text-align: left;
	font: bold 16px sans-serif;

	padding: 35px 30px;
	margin-top: 50px;
}

.footer-distributed .footer-left,
.footer-distributed .footer-center,
.footer-distributed .footer-right{
	display: inline-block;
	vertical-align: top;
}

/* Footer left */

.footer-distributed .footer-left{
	width: 40%;
}

/* The company logo */



.footer-distributed h3 span{
	color:  #5383d3;
}

/* Footer links */

.footer-distributed .footer-links{
	color:  #ffffff;
	margin: 20px 0 12px;
	padding: 0;
}

.footer-distributed .footer-links a{
	display:inline-block;
	line-height: 1.8;
	text-decoration: none;
	color:  inherit;
}

.footer-distributed .footer-company-name{
	color:  #8f9296;
	font-size: 14px;
	font-weight: normal;
	margin: 0;
}

/* Footer Center */

.footer-distributed .footer-center{
	width: 35%;
}

.footer-distributed .footer-center i{
	background-color:  #33383b;
	color: #ffffff;
	font-size: 25px;
	width: 38px;
	height: 38px;
	border-radius: 50%;
	text-align: center;
	line-height: 42px;
	margin: 10px 15px;
	vertical-align: middle;
}

.footer-distributed .footer-center i.fa-envelope{
	font-size: 17px;
	line-height: 38px;
}

.footer-distributed .footer-center p{
	display: inline-block;
	color: #ffffff;
	vertical-align: middle;
	margin:0;
}

.footer-distributed .footer-center p span{
	display:block;
	font-weight: normal;
	font-size:14px;
	line-height:2;
}

.footer-distributed .footer-center p a{
	color:  #5383d3;
	text-decoration: none;;
}


/* Footer Right */

.footer-distributed .footer-right{
	width: 20%;
}

.footer-distributed .footer-company-about{
	line-height: 10px;
	color:  #92999f;
	font-size: 13px;
	font-weight: normal;
	margin: 0;
}

.footer-distributed .footer-company-about span{
	display: block;
	color:  #ffffff;
	font-size: 14px;
	font-weight: bold;
	margin-bottom: 20px;
}

.footer-distributed .footer-icons{
	margin-top: 25px;
}

.footer-distributed .footer-icons a{
	display: inline-block;
	width: 40px;
	height: 40px;
	cursor: pointer;
	background-color:  #33383b;
	border-radius: 2px;

	font-size: 20px;
	color: #ffffff;
	text-align: center;
	line-height: 35px;

	margin-right: 3px;
	margin-bottom: 5px;
}

.copyright{
    color: #FFFFFF;
    width: 100%;
    background: #222222;
    border-top: 1px solid black;
    line-height: 10px;
}

/* If you don't want the footer to be responsive, remove these media queries */

@media (max-width: 880px) {

	.footer-distributed{
		font: bold 14px sans-serif;
	}

	.footer-distributed .footer-left,
	.footer-distributed .footer-center,
	.footer-distributed .footer-right{
		display: block;
		width: 100%;
		margin-bottom: 40px;
		text-align: center;
	}

	.footer-distributed .footer-center i{
		margin-left: 0;
	}
        .copyright{
    color: #FFFFFF;
    width: 100%;
    background: #222222;
    border-top: 1px solid black;
    line-height: 10px;
}

}

            
            
            
            .navbar-text > a {
    color: inherit; 
    text-decoration: none;
}
            
        </style>
    </head>
    <body>
        <footer class="footer-distributed">

			<div class="footer-left">
				<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ftpcollegemadhepura%2F&tabs=timeline&width=350&height=180&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="350" height="180" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
                             <h3>Total Visitors</h3>
                                <a href="https://www.easycounter.com/">
      <img src="https://www.easycounter.com/counter.php?tpcm"
      border="0" alt="Website Hit Counters"></a><br>                        </div>			

			<div class="footer-center">
                            <h3>Contact Us</h3>
				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>College Chowk</span> Madhepura, 852113 Bihar (INDIA).</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>06476-222809</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:info@tpcollege.org">tpcollegebnmu@gmail.com</a></p>                                       
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
                                    <h3>Follow us to Latest News &amp; Updates</h3>
					
				</p>

				<div class="footer-icons">

					<div class="social-icons">
                        <ul class="">
			     <li><a class="facebook" href="https://www.facebook.com/tpcollegemadhepura" target="_blank"> </a></li>
			     <li><a class="twitter" href="https://twitter.com/tpcollege" target="_blank"></a></li>
			     <li><a class="googleplus" href="https://plus.google.com/u/0/113662637588152401489" target="_blank"></a></li>				
			</ul>
		        </div>

				</div>

			</div>
            

		</footer>
<div class="copyright">
                <div class="well-sm">
                                        <p class="text-center">Copyright &copy; 2024 All Rights Reserved <a href="www.tpcollege.org" target="_blank">Thakur Prasad College,Madhepura</a></p></br>
                    <p class="text-center">Developed By <a href="#">TPC</a></p>
                </div>
            </div>
                       
                        
                        
    </body>
</html>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        
        
        <script src="../scripts/top.js" type="text/javascript"></script>
        <link href="../styles/top.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <a href="#0" class="cd-top">Top</a>
    </body>
</html>
    
    </body>
    
</html>