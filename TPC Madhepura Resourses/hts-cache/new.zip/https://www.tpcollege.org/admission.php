<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>::Admission::</title>
        <script src="../scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="../scripts/docs.min.js" type="text/javascript"></script>
        <script src="../scripts/ie10-viewport-bug-workaround.js" type="text/javascript"></script>
        <link href="../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
        <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="../scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
    </head>
    <body>
        <!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="en">
<head>
<meta charset="UTF-8">
<title></title>

<link href="../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<script src="../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../scripts/jquery-1.9.1.min.js" type="text/javascript"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link href="styles/custom-menu.css" rel="stylesheet" type="text/css"/>
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon"/>
<style type="text/css">
  
.header_bg{
    background: #20242C;
}
.tpc_logo{
                background: #20242C;
                width: 100%;
                
                margin-bottom: 5px;
            }
</style>
<script>

$(document).ready(function() {
	function bindNavbar() {
		if ($(window).width() > 767) {
			$('.navbar-default .dropdown').on('mouseover', function(){
				$('.dropdown-toggle', this).next('.dropdown-menu').show();
			}).on('mouseout', function(){
				$('.dropdown-toggle', this).next('.dropdown-menu').hide();
			});
			
			$('.dropdown-toggle').click(function() {
				if ($(this).next('.dropdown-menu').is(':visible')) {
					window.location = $(this).attr('href');
				}
			});
		}
		else {
			$('.navbar-default .dropdown').off('mouseover').off('mouseout');
		}
	}
	
	$(window).resize(function() {
		bindNavbar();
	});
	
	bindNavbar();
});
</script>

</head> 
<body >
   
    <div class="header_bg">
            <div class="container">
                <div class="row header">
                    <div class=" col-md-10">
                    <div class="tpc_logo navbar-left">
                        <img class="img-responsive" src="images/tpcollege.png" alt="Thakur Prasad College ,Madhepura"/>
                    </div>
                    </div>
                    <div class=" col-sm-2 pull-right ">
                     <div class="">
                         <a href="https://tp.collegeesolution.in/">
                             <button class="btn-ext" onclick="alert('You are being redirected to Apply-online section.')"><img class=" img-responsive" src="images/onld.gif" alt=""  style=" margin-top: 5px;"/></a>
                    </div>
                    </div>
                </div>    
            </div>
        </div>
        
    <nav role="navigation" class="navbar navbar-default" id="custom-bootstrap-menu">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            
        </div>
        <!-- Collection of nav links and other content for toggling -->
        <div id="navbarCollapse" class="collapse navbar-collapse navbar-menubuilder">
            <ul class="nav navbar-nav">
                <li class=" text-uppercase"><a href="index.php?term=Home"><span class="glyphicon glyphicon-home"></span> Home&nbsp;</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown" > &nbsp;About Us &nbsp; <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="intro.php?term=Introduction">Introduction</a></li>
                        <li><a href="principles_msg.php?term=Principle's Message">Principal's Message</a></li>
                        <li><a href="goals&objective.php?term=Goals & Objective">Goals & Objective</a></li>
                        <li><a href="#">UGC 2f &amp; 12b</a></li>
                        <li><a href="faculty.php">Faculty</a></li>
                        <li><a href="rules.php">Rules &amp; Regulation</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">&nbsp; &nbsp;Academic&nbsp; &nbsp; <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="admission.php">Admission</a></li>
                        <li><a href="examinations.php">Examination</a></li>
                        <li><a href="departments.php">Department</a></li>
                        <li><a href="#">Previous Year Questions</a></li>
                        <li><a href="fee&scholarship.php">Fee &amp; Scholarship</a></li>
                        <li><a href="calendar.php">Academic Calendar</a></li>
                        <li><a href="holidays.php">List of Holidays</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">&nbsp; &nbsp;Courses&nbsp;  <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
						<li><a href="onlinecourses.php">Online Courses</a></li>
                        <li><a href="course_higher_sec.php">Higher Secondary Courses</a></li>
                        <li><a href="course_ug.php">Under Graduate Courses</a></li>
                        <li><a href="course_pg.php">Post Graduate Courses</a></li>
                        <li><a href="course_voc.php">Vocational Program Courses</a></li>
                    </ul>
                </li>
                <!--<li><a href="campus.php">Campus</a></li>-->
                
                <li class="dropdown">
                    <a class="dropdown-toggle text-uppercase" data-toggle="dropdown" href="#"> &nbsp;Result&nbsp;  <strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="student_exam_result_ug.php">Under Graduate Course Result</a></li>
                        <li><a href="student_exam_result_pg.php">Post Graduate Course Result</a></li>
                        <li><a href="student_exam_result_voc.php">Vocational Course Result</a></li>
                        
                    </ul>
                </li>
                <li class="text-uppercase"><a href="gallery.php">Photo Gallery</a></li>
                <li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="dropdown" href="#">Downloads &nbsp;<strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li><a href="downloads.php">Download Prospectus</a></li>
                        <li><a href="#">Admission Form</a></li>
                        <li><a href="#">Other Forms</a></li>
                    </ul>
                </li>
				<li class="dropdown"><a class="dropdown-toggle text-uppercase" data-toggle="dropdown" href="#">NAAC &nbsp;<strong class="caret"></strong></a>
				<ul class="dropdown-menu">
                        <li><a href="naac.php">NAAC</a></li>
                        <li><a href="single.php">Contact Us</a></li>
                        
                    </ul>
                
				
                
            </ul>
            
        </div>
    </div>
        <!--<li class=" nav navbar-nav navbar-right dropdown">
                    <a class=" dropdown-toggle" data-toggle="dropdown" href="#"><i class=" glyphicon glyphicon-log-in"></i> Login </a>
                <ul class="dropdown-menu">
                    <li><a href="#">Admin Login</a></li>
                    <li><a href="#">Student Login</a></li>
                </ul>
                </li>-->
</nav>
    
</body>
</html>        <div class="container">
            <div class="row">
            <!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        
    </head>
    <body>
        
            
                <div class="col-sm-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4>Quick Links</h4>
                        </div>
                        <div class="panel-body">
                            <ul class="list-group">
                                <a href="index.php" class="list-group-item">Home</a>
                                <a href="intro.php" class="list-group-item">Introduction</a>
                                <a href=principles_msg.php#" class="list-group-item">Principle's Desk</a>
                                <a href="onlinecourses.php" class="list-group-item">Online Courses</a>
                                <a href="faculty.php" class="list-group-item">Directory</a>
								<a href="naac.php" class="list-group-item">NAAC</a>
                                <a href="rules.php" class="list-group-item">Rules &amp; Regulation</a>
                                <a href="admission.php" class="list-group-item">Admission Notice</a>
                                <a href="fee&scholarship.php" class="list-group-item">Fee &amp; Scholarship</a>
                                
                                <a href="#" class="list-group-item">Academic Calender</a>
                                <a href="holidays.php" class="list-group-item">List of Holidays</a>
                                <a href="http://tpcollegebed.org/" class="list-group-item">B.Ed.</a>
                            </ul>
                        </div>
                    </div>
                </div>
            
    </body>
</html>
                <div class="col-sm-9">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            <h3>Admission Notice</h3>
                        </div>
                        <div class="panel-body">
                            <table class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th>Sl. No.</th>
                                    <th>Course Name</th>
                                    <th>Last Date of Admission</th>
                                    <th>Prospectus</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>4</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
         <!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet">
<link href="styles/styles.css" rel="stylesheet" type="text/css"/>

        <style>
            
        footer h3{color: #FFFFFF;}            
            .footer-distributed{
	background-color: #292c2f;
	box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
	box-sizing: border-box;
	width: 100%;
	text-align: left;
	font: bold 16px sans-serif;

	padding: 35px 30px;
	margin-top: 50px;
}

.footer-distributed .footer-left,
.footer-distributed .footer-center,
.footer-distributed .footer-right{
	display: inline-block;
	vertical-align: top;
}

/* Footer left */

.footer-distributed .footer-left{
	width: 40%;
}

/* The company logo */



.footer-distributed h3 span{
	color:  #5383d3;
}

/* Footer links */

.footer-distributed .footer-links{
	color:  #ffffff;
	margin: 20px 0 12px;
	padding: 0;
}

.footer-distributed .footer-links a{
	display:inline-block;
	line-height: 1.8;
	text-decoration: none;
	color:  inherit;
}

.footer-distributed .footer-company-name{
	color:  #8f9296;
	font-size: 14px;
	font-weight: normal;
	margin: 0;
}

/* Footer Center */

.footer-distributed .footer-center{
	width: 35%;
}

.footer-distributed .footer-center i{
	background-color:  #33383b;
	color: #ffffff;
	font-size: 25px;
	width: 38px;
	height: 38px;
	border-radius: 50%;
	text-align: center;
	line-height: 42px;
	margin: 10px 15px;
	vertical-align: middle;
}

.footer-distributed .footer-center i.fa-envelope{
	font-size: 17px;
	line-height: 38px;
}

.footer-distributed .footer-center p{
	display: inline-block;
	color: #ffffff;
	vertical-align: middle;
	margin:0;
}

.footer-distributed .footer-center p span{
	display:block;
	font-weight: normal;
	font-size:14px;
	line-height:2;
}

.footer-distributed .footer-center p a{
	color:  #5383d3;
	text-decoration: none;;
}


/* Footer Right */

.footer-distributed .footer-right{
	width: 20%;
}

.footer-distributed .footer-company-about{
	line-height: 10px;
	color:  #92999f;
	font-size: 13px;
	font-weight: normal;
	margin: 0;
}

.footer-distributed .footer-company-about span{
	display: block;
	color:  #ffffff;
	font-size: 14px;
	font-weight: bold;
	margin-bottom: 20px;
}

.footer-distributed .footer-icons{
	margin-top: 25px;
}

.footer-distributed .footer-icons a{
	display: inline-block;
	width: 40px;
	height: 40px;
	cursor: pointer;
	background-color:  #33383b;
	border-radius: 2px;

	font-size: 20px;
	color: #ffffff;
	text-align: center;
	line-height: 35px;

	margin-right: 3px;
	margin-bottom: 5px;
}

.copyright{
    color: #FFFFFF;
    width: 100%;
    background: #222222;
    border-top: 1px solid black;
    line-height: 10px;
}

/* If you don't want the footer to be responsive, remove these media queries */

@media (max-width: 880px) {

	.footer-distributed{
		font: bold 14px sans-serif;
	}

	.footer-distributed .footer-left,
	.footer-distributed .footer-center,
	.footer-distributed .footer-right{
		display: block;
		width: 100%;
		margin-bottom: 40px;
		text-align: center;
	}

	.footer-distributed .footer-center i{
		margin-left: 0;
	}
        .copyright{
    color: #FFFFFF;
    width: 100%;
    background: #222222;
    border-top: 1px solid black;
    line-height: 10px;
}

}

            
            
            
            .navbar-text > a {
    color: inherit; 
    text-decoration: none;
}
            
        </style>
    </head>
    <body>
        <footer class="footer-distributed">

			<div class="footer-left">
				<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ftpcollegemadhepura%2F&tabs=timeline&width=350&height=180&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="350" height="180" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
                             <h3>Total Visitors</h3>
                                <a href="https://www.easycounter.com/">
      <img src="https://www.easycounter.com/counter.php?tpcm"
      border="0" alt="Website Hit Counters"></a><br>                        </div>			

			<div class="footer-center">
                            <h3>Contact Us</h3>
				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>College Chowk</span> Madhepura, 852113 Bihar (INDIA).</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>06476-222809</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:info@tpcollege.org">tpcollegebnmu@gmail.com</a></p>                                       
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
                                    <h3>Follow us to Latest News &amp; Updates</h3>
					
				</p>

				<div class="footer-icons">

					<div class="social-icons">
                        <ul class="">
			     <li><a class="facebook" href="https://www.facebook.com/tpcollegemadhepura" target="_blank"> </a></li>
			     <li><a class="twitter" href="https://twitter.com/tpcollege" target="_blank"></a></li>
			     <li><a class="googleplus" href="https://plus.google.com/u/0/113662637588152401489" target="_blank"></a></li>				
			</ul>
		        </div>

				</div>

			</div>
            

		</footer>
<div class="copyright">
                <div class="well-sm">
                                        <p class="text-center">Copyright &copy; 2024 All Rights Reserved <a href="www.tpcollege.org" target="_blank">Thakur Prasad College,Madhepura</a></p></br>
                    <p class="text-center">Developed By <a href="#">TPC</a></p>
                </div>
            </div>
                       
                        
                        
    </body>
</html>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        
        
        <script src="../scripts/top.js" type="text/javascript"></script>
        <link href="../styles/top.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <a href="#0" class="cd-top">Top</a>
    </body>
</html>
    </body>
</html>
